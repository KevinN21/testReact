import * as React from "react";
import * as ReactDOM from "react-dom";
// import {Col, Row} from "react-bootstrap";
// import './index.css'

import {
    SearchkitManager,
    SearchkitProvider,
    Hits,
    SearchBox,
    Layout,
    TopBar,
    LayoutBody,
    SideBar,
    HierarchicalMenuFilter,
    RefinementListFilter,
    LayoutResults,
    ActionBar,
    ActionBarRow,
    HitsStats,
    SelectedFilters,
    ResetFilters,
    MovieHitsGridItem,
    NoHits
} from "searchkit";

const qks = new SearchkitManager("http://optimus2.qks.io:9200/quarksds/substance")

class App extends React.Component {

    render() {
        return (

            <SearchkitProvider searchkit={qks}>
                <Layout>
                    <TopBar>
                                <SearchBox autofocus={true} searchOnChange={true} placeholder={'Search ...'}/>
                    </TopBar>
                    <LayoutBody>
                        <SideBar>
                            <HierarchicalMenuFilter fields={["type.raw", "genres.raw"]} title="Categories" id="categories"/>
                            <RefinementListFilter id="actors" title="actors" field="actors.raw" operator="aw" size={10}/>
                        </SideBar>

                        <LayoutResults>
                            <ActionBar>

                                <ActionBarRow>
                                    <HitsStats/>
                                </ActionBarRow>

                                <ActionBarRow>
                                    <SelectedFilters/>
                                    <ResetFilters/>
                                </ActionBarRow>

                            </ActionBar>
                                <Hits mod="sk-hits-grid" hitsPerPage={40} itemComponent={MovieHitsGridItem}/>
                                    <NoHits/>
                        </LayoutResults>
                    </LayoutBody>
                </Layout>
            </SearchkitProvider>
        )
    }
};

ReactDOM.render(
    <App/>, document.body);
